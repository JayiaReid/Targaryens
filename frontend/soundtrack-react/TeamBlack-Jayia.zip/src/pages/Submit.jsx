import { useState } from 'react';
import Header from '../components/Header';
import '../css/submit.css'

function Submit() {
    const [songName, setSongName] = useState('');
    const [songReview, setSongReview] = useState('');
    const [songRating, setSongRating] = useState(0);

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log('Submitted review:', { songName, songReview, songRating });
        setSongName('');
        setSongReview('');
        setSongRating(0);
        alert("submitted");
    };

    return (
        <div id='submitpage'>
            <Header/>
            <div>
            <h2 className='s_h'>Submit a Review</h2>
            <form onSubmit={handleSubmit}>
                <div>
                <select id="songSelect">
                    <option value="">Select a song...</option>
                    <option value="coj">Crown of Jaeherys</option>
                    <option value="tgt">Targaryen Theme</option>
                    <option value="fbts">Funeral by the Sea</option>
                    <option value="daemyra">Daemyra</option>
                    <option value="dae">The Rogue Prince</option>
                    <option value="promise">The Promise</option>
                </select>
                </div>
                <div>
                    
                    <textarea
                        id="songReview"
                        value={songReview}
                        onChange={(e) => setSongReview(e.target.value)}
                        required
                        placeholder='Enter review here'
                    ></textarea>
                </div>
               
                <button type="submit" className='s_s_btn'>Submit Review</button>
            </form>
        </div></div>
    );
}

export default Submit;
